<?php

/**
 * Inchoo Productfilter helper
 *
 * @category   Inchoo
 * @package    Productfilter
 * @author     Milovan Gal <milovan.gal@inchoo.net>
 */
class Inchoo_Productfilter_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}
