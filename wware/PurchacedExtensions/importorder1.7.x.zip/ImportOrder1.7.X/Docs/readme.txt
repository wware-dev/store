1) Order create work only for Simple Product Type.
2) Complete Order Update Work for all Product Type.
3) Partial Order Update Work for Simple,Configurable,Grouped
4) Single Invoice and Shipment Support.