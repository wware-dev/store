<?php
class Moogento_Pickpack_Helper_Data extends Mage_Core_Helper_Abstract
{
}