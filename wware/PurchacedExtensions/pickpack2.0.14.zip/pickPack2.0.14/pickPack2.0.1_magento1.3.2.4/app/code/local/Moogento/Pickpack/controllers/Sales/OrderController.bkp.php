<?php
require_once 'app/code/core/Mage/Adminhtml/controllers/Sales/OrderController.php';
class Moogento_Pickpack_Sales_OrderController extends Mage_Adminhtml_Sales_OrderController
{

	/**
	 * Class Constructor
	 * call the parent Constructor
	 */

	public function __constuct()
	{
		parent::__construct();
	}

	/**
	 * Delete selected orders
	 
	public function deleteAction()
	{
		$orderIds = $this->getRequest()->getPost('order_ids', array());
		$countDeleteOrder = 0;
		foreach ($orderIds as $orderId) {
			$order = Mage::getModel('pickpack/order')->load($orderId);
			if ($order->canDelete()) {
				$order->delete()
				->delete();
				$countDeleteOrder++;
			}
		}
		if ($countDeleteOrder>0) {
			$this->_getSession()->addSuccess($this->__('%s order(s) successfully deleted', $countDeleteOrder));
		}
		else {
			// selected orders is not available for delete
			$this->_getSession()->addError($this->__('Please cancel your order before delete it. Only order without invoice, shipment or creditmemo could be deleted.', $countDeleteOrder));
		}

		$this->_redirect('adminhtml/sales_order/', array());

	}
*/

	// packing sheet
	public function packAction(){
		$orderIds = $this->getRequest()->getPost('order_ids');
		$flag = false;
		if (!empty($orderIds)) {
			foreach ($orderIds as $orderId) {
				/*$order = Mage::getModel('sales/order')->load($orderId);

				$Invoices = Mage::getResourceModel('sales/order_invoice_collection')
				->addAttributeToSelect('*')
				->setOrderFilter($orderId)
				->load();
				if ($Invoices->getSize() > 0) {*/
					$flag = true;
					if (!isset($pdf)){
						$pdf = Mage::getModel('sales/order_pdf_Invoices')->getmooPdf($orderId);
					} else {
						$pages = Mage::getModel('sales/order_pdf_Invoices')->getmooPdf($orderId);
						$pdf->pages = array_merge ($pdf->pages, $pages->pages);
					}
				//}
			}
			if ($flag) {
				return $this->_prepareDownloadResponse('packing-slip'.Mage::getSingleton('core/date')->date('Y-m-d_H-i-s').'.pdf', $pdf->render(), 'application/pdf');
			} else {
				$this->_getSession()->addError($this->__('There are no printable documents related to selected orders'));
				$this->_redirect('*/*/');
			}

		}
		$this->_redirect('*/*/');

	}

	// separated pick list
	public function pickAction(){
		$orderIds = $this->getRequest()->getPost('order_ids');
		// $flag = false;
		// 	$a = array();
		// 	if (!empty($orderIds)) {
		// 		foreach ($orderIds as $orderId) {
		// 			$order = Mage::getModel('sales/order')->load($orderId);
		// 			$shipments = Mage::getResourceModel('sales/order_invoice_collection')
		// 			->addAttributeToSelect('*')
		// 			->setOrderFilter($orderId)
		// 			->load();
		// 			if ($shipments->getSize() > 0) {
		// 				$flag = true;
		// 				foreach ($shipments as $v){
		// 					$a[]  = $v;
		// 				}
		// 			}
		// 		}
		if (!empty($orderIds)) 
		{
			$pdf = Mage::getModel('sales/order_pdf_shipment')->getmooPdf($orderIds);
			// if ($flag) {
			return $this->_prepareDownloadResponse('picklist-separated'.Mage::getSingleton('core/date')->date('Y-m-d_H').'.pdf', $pdf->render(), 'application/pdf');
			// } else {
			// 				$this->_getSession()->addError($this->__('There are no printable documents related to selected orders'));
			// 				$this->_redirect('*/*/');
			// 			}
		}
		//}
		$this->_redirect('*/*/');
	}

	// combined pick list
	public function enpickAction(){
		$orderIds = $this->getRequest()->getPost('order_ids');

		if (!empty($orderIds)) 
		{
			$pdf = Mage::getModel('sales/order_pdf_pick')->getmooPdf($orderIds);
			return $this->_prepareDownloadResponse('picklist-combined'.Mage::getSingleton('core/date')->date('Y-m-d_H-i-s').'.pdf', $pdf->render(), 'application/pdf');
		}
		
		$this->_redirect('*/*/');
	}
}
