<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category   Mage
 * @package    Mage_Sales
 * @copyright  Copyright (c) 2008 Irubin Consulting Inc. DBA Varien (http://www.varien.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Sales Order Invoice PDF model
 *
 * @category   Mage
 * @package    Mage_Sales
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Mage_Sales_Model_Order_Pdf_mooInvoices extends Mage_Sales_Model_Order_Pdf_Aabstract
{
    public function getmooPdf($orderId = '')
    {
		$simple = true;//set to true to hide addresses
		$configurable_names = 'simple'; //set to simple to show simple product names (instead of configurable product names)

		$qtyX = 420;
		$skuX = 255;
		$productX = 35;

		$order = Mage::getModel('sales/order')->load($orderId);

		$itemsCollection=  $order->getAllVisibleItems();
		$total_items    = count($itemsCollection);
		//$mooInvoices 		= Mage::getResourceModel('sales/order');

		$show_price 	= 0;
		$this->_beforegetmooPdf();
		$this->_initRenderer('invoice');
		$pdf 			= new Zend_Pdf();
		$this->_setPdf($pdf);
		$style 			= new Zend_Pdf_Style();
		$this->_setFontBold($style, 10);
		$page 			= $pdf->newPage(Zend_Pdf_Page::SIZE_A4);
		$pdf->pages[] 	= $page;

		/* Add head */
		$this->insertOrder($page, $order, Mage::getStoreConfigFlag(self::XML_PATH_SALES_PDF_INVOICE_PUT_ORDER_ID, $order->getStoreId()),$simple);
		$page->setFillColor(new Zend_Pdf_Color_GrayScale(1));
		$this->_setFontRegular($page);

		/* Add products list table */      
		$page->setFillColor(new Zend_Pdf_Color_Rgb(0.93, 0.92, 0.92));
		$page->setLineColor(new Zend_Pdf_Color_GrayScale(0.92));
		$this->_setFontItalic($page,14);  
		$page->drawRectangle(25, $this->y, 570, $this->y -20);
		$this->y -=15;
		$page->setFillColor(new Zend_Pdf_Color_RGB(0.4, 0.4, 0.4));
		$page->drawText(Mage::helper('sales')->__('item'), $productX, $this->y, 'UTF-8');
		$page->drawText(Mage::helper('sales')->__('code'), ($skuX-5), $this->y, 'UTF-8');
		$page->drawText(Mage::helper('sales')->__('qty'), ($qtyX-5), $this->y, 'UTF-8');
		$this->y -=30;

	//	$this->y = 660;
		
		if(!$simple)
		{
			//$this->y = 600;
		
			/* Add image */
			$this->insertLogo($page, $order->getStore());

			/* Add address */
			$store_address = $this->insertAddress($page, 'top', $order->getStore());

			$productY = $this->y;
			// bottom address label
			$this->y =115;
			$page->setFillColor(new Zend_Pdf_Color_RGB(0.4, 0.4, 0.4));

			/* Add bottom store address */
			$store_address = $this->insertAddress($page, 'bottom', $order->getStore());
			
			$this->y = $productY;
		}
		
		$page->setFillColor(new Zend_Pdf_Color_GrayScale(0));

		$this->_setFontRegular($page,10);

		foreach ($itemsCollection as $item)
		{
			if ($this->y < 15) 
			{
				$page = $this->newPage(array('table_header' => true));
			}

			if($item->getProductType() == Mage_Catalog_Model_Product_Type::TYPE_CONFIGURABLE) 
			{
				$sku = $item->getProductOptionByCode('simple_sku');
				$product_id = Mage::getModel('catalog/product')->getIdBySku($sku);
			} 
			else 
			{
				$sku = $item->getSku();
				$product_id = $item->getProductId(); // get it's ID			
			}	

			$custom_options_output = '';

			$options = $item->getProductOptions();			
			
			$name = '';
			if(Mage::getModel('catalog/product')->load($product_id) && $configurable_names == 'simple')
			{
				$_newProduct = Mage::getModel('catalog/product')->load($product_id);  
				if($_newProduct->getData('name')) $name = $_newProduct->getData('name');
			}
			else $name = $item->getName();
			
			$breakpoint = 40;
			$display_name = '';
			$name_length = 0;
			if(strlen($name) > ($breakpoint+2))
			{
				$display_name = substr(htmlspecialchars_decode($name), 0, ($breakpoint)).'…';
			}
			else $display_name = htmlspecialchars_decode($name);
			
			$breakpoint = 24;
			$display_sku = '';
			$sku_length = 0;
			if(strlen($sku) > ($breakpoint+2))
			{
				$display_sku = substr(htmlspecialchars_decode($sku), 0, ($breakpoint)).'…';
			}
			else $display_sku = htmlspecialchars_decode($sku);

			 /* Draw item */
			$qty = $item->getIsQtyDecimal() ? $item->getQtyOrdered() : (int) $item->getQtyOrdered();
			$page->drawText($qty, $qtyX, $this->y , 'UTF-8');                    
			$page->drawText($display_name, $productX, $this->y , 'UTF-8');
			$page->drawText($display_sku, $skuX, $this->y , 'UTF-8');

			if(isset($options['options']))
			{
				if(is_array($options['options']))
				{
					$this->_setFontRegular($page,8);
					$i = 0;

					if(isset($options['options'][$i])) $continue = 1;
					else $continue = 0;

					while($continue == 1)
					{
						$this->y -=12;
						
						if(trim($options['options'][$i]['label'].$options['options'][$i]['value']) != '')
						{
							// if($i > 0) $custom_options_output .= ' ';
							$custom_options_output = htmlspecialchars_decode('[ '.$options['options'][$i]['label'].' : '.$options['options'][$i]['value'].' ]');
							$page->drawText($custom_options_output, ($skuX+12), $this->y , 'UTF-8');
						}
						$i ++;

						if(isset($options['options'][$i])) $continue = 1;
						else $continue = 0;
					}
				}
				$this->_setFontRegular($page,10);
				
			}
			
		/*
			if(isset($custom_options_output))
					{
						$this->y -=12;
						$this->_setFontRegular($page,8);
						$page->drawText($custom_options_output, $skuX, $this->y , 'UTF-8');
						$this->_setFontRegular($page,10);
						
					}
		*/
		
			$sku_print = $sku;

			if(isset($options['bundle_options']) && is_array($options['bundle_options']))
			{
				$this->y -=12;
				$this->_setFontRegular($page,8);
				
				$bundle_options_sku = 'SKU : '.$sku_print;
				$sku_print = '(Bundle)';
				$bundle_sku_test = $sku;
				
				$product_build['bundle_options_sku'] 	= $bundle_options_sku;	
				$product_build['bundle_children'] 		= $item->getChildrenItems();
				$product_build['bundle_qty_shipped'] 	= (int)$item->getQtyShipped();
				
				
				$line_height = 12;
				
				foreach($product_build['bundle_children'] as $child)
				{
	                $product = Mage::getModel('catalog/product')->load($child->getProductId());
					$sku = $child->getSku();
					$price = $child->getPriceInclTax();
					$qty = (int)$child->getQtyOrdered();
					$name = $child->getName();


					$qty_string = $qty;
					$price_qty = $qty;
					$productXInc = 0;
					// }

					$breakpoint = 40;
					$display_name = '';
					$name_length = 0;
					if(strlen($name) > ($breakpoint+2))
					{
						$display_name = substr(htmlspecialchars_decode($name), 0, ($breakpoint)).'…';
					}
					else $display_name = htmlspecialchars_decode($name);

					$page->drawText($sku, ($skuX+12), $this->y , 'UTF-8');
					$page->drawText($qty_string, $qtyX, $this->y , 'UTF-8');
					$page->drawText($display_name, ($productX+12) , $this->y , 'UTF-8');
					$this->y -= $line_height;
													
				}
			
				// $this->y -=12;
				// $page->drawText((int)$item->getQtyShipped(), $qtyX, $this->y , 'UTF-8');                    
				// $page->drawText($item->getChildrenItems(), $productX, $this->y , 'UTF-8');
				// $page->drawText($bundle_options_sku, $skuX, $this->y , 'UTF-8');										
				// $this->y -=0;
		
			}		
		
			$this->y -=20;

			 //$page = $this->_drawItem($item, $page, $order);
			
			$this->_setFontRegular($page,10);
			
			unset($product_build);
			unset($product_build_value);
			unset($sku);
		}

		$this->_aftergetmooPdf();

		return $pdf;
    }

    /**
     * Create new page and assign to PDF object
     *
     * @param array $settings
     * @return Zend_Pdf_Page
     */
    public function newPage(array $settings = array())
    {
        /* Add new table head */
		$show_price = 0;
        $page = $this->_getmooPdf()->newPage(Zend_Pdf_Page::SIZE_A4);
        $this->_getmooPdf()->pages[] = $page;
        $this->y = 800;


        if (!empty($settings['table_header'])) {
            $this->_setFontRegular($page);
            $page->setFillColor(new Zend_Pdf_Color_RGB(0.93, 0.92, 0.92));
            $page->setLineColor(new Zend_Pdf_Color_GrayScale(0.5));
            $page->setLineWidth(0.5);

			//                   ? xpos header rectangle  ? width            ? height header rectangle
            $page->drawRectangle(25, $this->y, 570, $this->y-15);
            
			$this->y -=10;

            $page->setFillColor(new Zend_Pdf_Color_RGB(0.4, 0.4, 0.4));
            $page->drawText(Mage::helper('sales')->__('Product'), 35, $this->y, 'UTF-8');
            $page->drawText(Mage::helper('sales')->__('SKU'), 255, $this->y, 'UTF-8');
            if($show_price > 0) $page->drawText(Mage::helper('sales')->__('Price'), 380, $this->y, 'UTF-8');
            $page->drawText(Mage::helper('sales')->__('QTY'), 430, $this->y, 'UTF-8');
            //$page->drawText(Mage::helper('sales')->__('Tax'), 480, $this->y, 'UTF-8');
            if($show_price > 0) $page->drawText(Mage::helper('sales')->__('Subtotal'), 535, $this->y, 'UTF-8');

            $page->setFillColor(new Zend_Pdf_Color_GrayScale(0));
            $this->y -=20;
        }

        return $page;
    }
}