<?php
class Moogento_Pickpack_Block_Sales_Order_Grid extends Mage_Adminhtml_Block_Sales_Order_Grid
{

	public function __construct()
	{
		parent::__construct();
	}

	protected function _prepareMassaction()
	{
		parent::_prepareMassaction();
		
		$this->getMassactionBlock()->addItem('seperator1', array(
		     'label'=> Mage::helper('sales')->__('---------------'),
		     'url'  => '',
		));
		
		$this->getMassactionBlock()->addItem('pdfpack_order', array(
		     'label'=> Mage::helper('sales')->__('PDF Packing Sheets'),
		     'url'  => $this->getUrl('pickpack/sales_order/pack'),
		));

		$this->getMassactionBlock()->addItem('pdfpick_order', array(
		     'label'=> Mage::helper('sales')->__('PDF Order-separated Pick List'),
		     'url'  => $this->getUrl('pickpack/sales_order/pick'),
		));
		
		$this->getMassactionBlock()->addItem('pdfenpick_order', array(
		     'label'=> Mage::helper('sales')->__('PDF Order-combined Pick List'),
		     'url'  => $this->getUrl('pickpack/sales_order/enpick'),
		));
		
		/*
		
		$this->getMassactionBlock()->addItem('delete_order', array(
            'label'=> Mage::helper('sales')->__('Delete'),
		    'url'  => $this->getUrl('pickpack/sales_order/delete', array('_current'=>true)),
		));
		*/
		

		return $this;
	}
}
