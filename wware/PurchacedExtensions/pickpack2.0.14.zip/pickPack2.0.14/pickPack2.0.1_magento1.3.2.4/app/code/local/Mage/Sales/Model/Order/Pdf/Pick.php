<?php
/**
 * Sales Order Shipment PDF model
 *
 * @category   Mage
 * @package    Mage_Sales
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Mage_Sales_Model_Order_Pdf_Pick extends Mage_Sales_Model_Order_Pdf_Aabstract
{
	public function getmooPdf($shipments = array())
	{
		$this->_beforegetmooPdf();
		$this->_initRenderer('shipment');
		$pdf = new Zend_Pdf();
		$this->_setPdf($pdf);
		$style = new Zend_Pdf_Style();

		$page = $pdf->newPage(Zend_Pdf_Page::SIZE_A4);
		$pdf->pages[] = $page;

		$this->_setFontBold($style, 10);

		// page title
		$page->setFillColor(new Zend_Pdf_Color_GrayScale(0));
		$this->_setFontItalic($page,20);
		$page->drawText(Mage::helper('sales')->__('Combined SKU Pick List'), 31, 800, 'UTF-8');

		$this->y = 777;

		$sku_master 	= array();
		$sku_qty 		= array();
		$sku_cost 		= array();
		$total_cost		= 0;
		$total_qty		= 0;
		$total_order_qty = 0;
		$order_qty = 0;
		
		foreach ($shipments as $shipment) 
		{			
			$order = Mage::getModel('sales/order')->load($shipment);
			
			$order_qty = $order['total_item_count'];
			$total_order_qty = ($total_order_qty + $order_qty);
			
			$itemsCollection=  $order->getAllVisibleItems();
			$total_items    = count($itemsCollection);
			
			foreach ($itemsCollection as $item)
			{
			
				if($item->getProductType() == Mage_Catalog_Model_Product_Type::TYPE_CONFIGURABLE) 
				{
					$sku 		= $item->getProductOptionByCode('simple_sku');
					$product_id = Mage::getModel('catalog/product')->getIdBySku($sku);
				} 
				else 
				{
					$sku 		= $item->getSku();
					$product_id = $item->getProductId(); // get it's ID			
				}
				
				$item_qty = $item->getIsQtyDecimal() ? $item->getQtyOrdered() : (int) $item->getQtyOrdered();
			
				$item_cost	= $item_qty*($item->getCost());
			
				if(!isset($sku_qty[$sku])) $sku_qty[$sku] = $item_qty;
				else $sku_qty[$sku] = ($sku_qty[$sku] + $item_qty);
				$total_qty = ($total_qty + $item_qty);
			
				if(!isset($sku_cost[$sku])) $sku_cost[$sku] = $item_cost;
				else $sku_cost[$sku] = ($sku_cost[$sku] + $item_cost);
				$total_cost = ($total_cost + $item_cost);
			
				if(!in_array($sku,$sku_master)) $sku_master[] = $sku;
			}
		}
		
		ksort($sku_master,SORT_REGULAR);
		
		$this->_setFontRegular($page,10);
		
		$grey_bkg_color	= new Zend_Pdf_Color_GrayScale(0.7);
		$black_bkg_color= new Zend_Pdf_Color_GrayScale(0);

		$grey_next_line = 0;
		foreach($sku_master as $sku)
		{
			if ($this->y<40) 
			{
				$page = $this->newPage();
			}
			
			if($grey_next_line == 1)
			{
				$page->setFillColor($grey_bkg_color);			
				$page->setLineColor($grey_bkg_color);	
				$page->drawRectangle(29, ($this->y-2), 570, ($this->y+9));
				$grey_next_line = 0;
			}
			else $grey_next_line = 1;
			
			$page->setFillColor($black_bkg_color);			
			$page->setLineColor($black_bkg_color);	
			
			$page->drawText($sku_qty[$sku] . '  x  '.$sku, 31, $this->y , 'UTF-8');                    
			$this->y -= 11;
		}

		$this->y -= 20;

		$lineBlock = array(
            'lines'  => array(),
            'height' => 15
		);

		$lineBlock['lines'][] = array(
		array(
                            'text'      => "total quantity",
                            'feed'      => 475,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            ),
                            array(
                            'text'      => $total_qty,
                            'feed'      => 565,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            )
                            );
	if($total_cost > 0)
	{
      $lineBlock['lines'][] = array(
      array(
                            'text'      => "total cost",
                            'feed'      => 475,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            ),
                            array(
                            'text'      => $total_cost,
                            'feed'      => 565,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            )
                            );
	}
	
   	$page = $this->drawLineBlocks($page, array($lineBlock));

	$this->_aftergetmooPdf();

	return $pdf;
	}


	public function newPage(array $settings = array())
	{
		$page = $this->_getmooPdf()->newPage(Zend_Pdf_Page::SIZE_A4);
		$this->_getmooPdf()->pages[] = $page;
		$this->y = 800;
		return $page;
	}
}