<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category   Mage
 * @package    Mage_Sales
 * @copyright  Copyright (c) 2008 Irubin Consulting Inc. DBA Varien (http://www.varien.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Sales Order Shipment PDF model
 *
 * @category   Mage
 * @package    Mage_Sales
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Mage_Sales_Model_Order_Pdf_Shipment extends Mage_Sales_Model_Order_Pdf_Aabstract
{
    public function getmooPdf($shipments = array())
    {

		$this->_beforegetmooPdf();
		$this->_initRenderer('shipment');
		$pdf = new Zend_Pdf();
		$this->_setPdf($pdf);
		$style = new Zend_Pdf_Style();

		$page = $pdf->newPage(Zend_Pdf_Page::SIZE_A4);
		$pdf->pages[] = $page;

	    $this->_setFontBold($style, 10);
    

		// page title
		$page->setFillColor(new Zend_Pdf_Color_GrayScale(0));
		$this->_setFontItalic($page,20);
		$page->drawText(Mage::helper('sales')->__('Order-Separated Pick List'), 31, 800, 'UTF-8');
		
		$this->y = 777;
		
		$sku_master 	= array();
		$sku_qty 		= array();
		$sku_cost 		= array();
		$total_cost		= 0;
		$total_qty		= 0;
		$total_order_qty = 0;
		$order_qty = 0;
		
        foreach ($shipments as $shipment) 
		{
			$order = Mage::getModel('sales/order')->load($shipment);

			// ID rectangle
			$page->setFillColor(new Zend_Pdf_Color_Rgb(0.93, 0.92, 0.92));
			$page->setLineColor(new Zend_Pdf_Color_GrayScale(0.92));
			$page->drawRectangle(27, $this->y, 570, ($this->y - 20));
			
			// order #
			$page->setFillColor(new Zend_Pdf_Color_GrayScale(0.3));
			$this->_setFontBold($page,14);
			$page->drawText(Mage::helper('sales')->__('#') .$order->getRealOrderId(), 31, ($this->y - 15), 'UTF-8');
			$page->setFillColor(new Zend_Pdf_Color_GrayScale(0));

			$this->_setFontRegular($page,10);
			
			$this->y -= 30;
		
			$order_qty = $order['total_item_count'];
			$total_order_qty = ($total_order_qty + $order_qty);
		
			$itemsCollection=  $order->getAllVisibleItems();
			$total_items    = count($itemsCollection);
		
			foreach ($itemsCollection as $item)
			{
				// if ($item->getOrderItem()->getParentItem()) {
				//                     continue;
				//                 }
				if($item->getProductType() == Mage_Catalog_Model_Product_Type::TYPE_CONFIGURABLE) 
				{
					$sku 		= $item->getProductOptionByCode('simple_sku');
					$product_id = Mage::getModel('catalog/product')->getIdBySku($sku);
				} 
				else 
				{
					$sku 		= $item->getSku();
					$product_id = $item->getProductId(); // get it's ID			
				}

				$item_qty = $item->getIsQtyDecimal() ? $item->getQtyOrdered() : (int) $item->getQtyOrdered();

				$item_cost	= $item_qty*($item->getCost());

				if(!isset($sku_qty[$sku])) $sku_qty[$sku] = $item_qty;
				else $sku_qty[$sku] = ($sku_qty[$sku] + $item_qty);
				$total_qty = ($total_qty + $item_qty);

				if(!isset($sku_cost[$sku])) $sku_cost[$sku] = $item_cost;
				else $sku_cost[$sku] = ($sku_cost[$sku] + $item_cost);
				$total_cost = ($total_cost + $item_cost);

				if(!in_array($sku,$sku_master)) $sku_master[] = $sku;

				/* Draw item */
				$page->drawText($item_qty . '  x  '.$sku, 31, $this->y , 'UTF-8');                    
			
				// draw name
				$sku_name = $item->getName();
				$page->drawText($sku_name, 150, $this->y , 'UTF-8');                    
				
				$this->y -= 11;
			
				if ($this->y<40) {
                    $page = $this->newPage();
                }				
			}			
        }
	
		$this->y -= 20;

		$lineBlock = array(
            'lines'  => array(),
            'height' => 15
		);

		$lineBlock['lines'][] = array(
		array(
                            'text'      => "total quantity",
                            'feed'      => 475,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            ),
                            array(
                            'text'      => $total_qty,
                            'feed'      => 565,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            )
                            );
	if($total_cost > 0)
	{
      $lineBlock['lines'][] = array(
      array(
                            'text'      => "total cost",
                            'feed'      => 475,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            ),
                            array(
                            'text'      => $total_cost,
                            'feed'      => 565,
                            'align'     => 'right',
                            'font_size' => 10,
                            'font'      => 'bold'
                            )
                            );
	}

   	$page = $this->drawLineBlocks($page, array($lineBlock));

	$this->_setFontBold($page);
$page->drawText(Mage::helper('sales')->__('Printed:').'   '.date('l jS F Y h:i:s A', Mage::getModel('core/date')->timestamp(time())), 210, 18, 'UTF-8');

	$this->_aftergetmooPdf();

	return $pdf;
}

    /**
     * Create new page and assign to PDF object
     *
     * @param array $settings
     * @return Zend_Pdf_Page
     */
    public function newPage(array $settings = array())
    {
        /* Add new table head */
        $page = $this->_getmooPdf()->newPage(Zend_Pdf_Page::SIZE_A4);
        $this->_getmooPdf()->pages[] = $page;
        $this->y = 800;

        // if (!empty($settings['table_header'])) {
        //           $this->_setFontRegular($page);
        //           $page->setFillColor(new Zend_Pdf_Color_RGB(0.93, 0.92, 0.92));
        //           $page->setLineColor(new Zend_Pdf_Color_GrayScale(0.5));
        //           $page->setLineWidth(0.5);
        //           $page->drawRectangle(25, $this->y, 570, $this->y-15);
        //           $this->y -=10;
        // 
        //           $page->setFillColor(new Zend_Pdf_Color_RGB(0.4, 0.4, 0.4));
        //           $page->drawText(Mage::helper('sales')->__('QTY'), 35, $this->y, 'UTF-8');
        //           $page->drawText(Mage::helper('sales')->__('Products'), 60, $this->y, 'UTF-8');
        //           $page->drawText(Mage::helper('sales')->__('SKU'), 470, $this->y, 'UTF-8');
        // 
        //           $page->setFillColor(new Zend_Pdf_Color_GrayScale(0));
        //           $this->y -=20;
        //       }

        return $page;
    }
}