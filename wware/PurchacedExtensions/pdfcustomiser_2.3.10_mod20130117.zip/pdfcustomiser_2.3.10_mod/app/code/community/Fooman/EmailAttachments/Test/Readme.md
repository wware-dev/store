Tests currently use the Ecomdev fork at
https://github.com/fooman/EcomDev_PHPUnit/commits/master