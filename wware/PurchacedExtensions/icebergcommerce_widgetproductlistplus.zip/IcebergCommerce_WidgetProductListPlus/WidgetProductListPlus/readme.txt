Iceberg Commerce Product List Plus Widget - Magento Extension
Version 2.0
June 2012 
User Support: http://icebergcommerce.com/software/contacts


Installation:
--------------

 1. Unzip IcebergCommerce_WidgetListProductsFiltered.zip
 2. Copy WidgetListProductsFiltered/app/code/community/IcebergCommerce/WidgetListProductsFiltered folder to your store under app/code/community/IcebergCommerce/
 3. Copy WidgetListProductsFiltered/etc/modules/IcebergCommerce_WidgetListProductsFiltered.xml to your app/etc/modules folder
 4. Log into your Magento admin panel
 5. Clear your Magento Cache (System > Cache Management)


Usage:
--------------

 1. Go to any cms page or block and click on the insert widget button
 2. You should see the widget "(Iceberg Commerce) Product List Plus"
 3. After selecting the widget, wait a few moments for the widget options to load
 4. After selecting options, insert the widget and save the cms page or block


Troubleshooting:
------------------

If you are experiencing problems with correct products not showing up
when using the widget, please try the following:

- Ensure that the attribute(s) that you are filtering by are one of
(a) Filterable with results
(b) Filterable with no results
(c) Used in product listing

These options are found on the attribute edit page

- Ensure that all your Magento system indexes are refreshed.
System > Index Management


