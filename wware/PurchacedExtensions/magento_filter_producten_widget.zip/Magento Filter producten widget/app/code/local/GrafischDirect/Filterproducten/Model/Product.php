<?php
class GrafischDirect_Filterproducten_Model_Product extends Mage_Catalog_Model_Product
{
    
	
}