<?php
class GrafischDirect_Filterproducten_Block_Productsfilterwidget extends Mage_Catalog_Block_Product_List implements Mage_Widget_Block_Interface
{
    /**
     * Retrieve loaded category collection
     *	$midM = round(memory_get_usage()/1048576,2) . "\n"; // 36640
		$usedM = $midM-$startM;
		echo "<br>Dung 1 : {$usedM}</br>";
     * @return Mage_Eav_Model_Entity_Collection_Abstract
     */

    protected $_productCollection;

	
	public function getLoadedProductCollection()
	{		
		return $this->getProductCollection();
	}
	
    protected function getProductCollection()
    {	
		$in = $this->getConfigs();
		$reg = Mage::registry('config');
		if($reg)
			Mage::unregister('config');
		Mage::register('config',$in);		
		//echo '<pre>';print_r($in);exit;
		
		$visibility = array(
			  Mage_Catalog_Model_Product_Visibility::VISIBILITY_BOTH,
			  Mage_Catalog_Model_Product_Visibility::VISIBILITY_IN_CATALOG
			  );
		
		$lib_multicache	=	Mage::helper('productsfilterwidget/multicache');		
		$tam	=	$lib_multicache->get('conditions_'.$in['time']);
		//echo '<pre>';print_r($tam);exit;
		if(!$tam)
		{
			$catalogRule = Mage::getModel('productsfilterwidget/rule');		
			$actionsArr = unserialize($in['conditions']);
			if (!empty($actionsArr) && is_array($actionsArr)) {
				$catalogRule->getConditions()->loadArray($actionsArr);
			}
			//addAttributeToSelect('*')->addStoreFilter(Mage::app()->getStore()->getId())->addAttributeToFilter('visibility', $visibility)
			
			
			$model 		= 	Mage::getModel('catalog/product');
			$collection	=	$model->getCollection()->addAttributeToFilter('status',1)->addAttributeToSelect('*')->addStoreFilter(Mage::app()->getStore()->getId())->addAttributeToFilter('visibility', $visibility);
			$collection->setPageSize(500);
			$tong	=	count($collection->getData());
			
			
			$offset	=	$tong;
			while($tong == 500)
			{				
				foreach($collection as $_product)
				{
					$object = new Varien_Object();
					$object->setData('product', $_product);
					if($catalogRule->validate($object))			
						$tam[]	=	$_product->getId();
				}
				
				$collection	=	$model->getCollection()->addAttributeToFilter('status',1)->addAttributeToSelect('*')->addStoreFilter(Mage::app()->getStore()->getId())->addAttributeToFilter('visibility', $visibility);
				$collection->getSelect()->limit($tong, $offset);
				
				$tong = count($collection->getData());
				$offset	+=	$tong;
			}		
			if($tong > 0 )
			{
				foreach($collection as $_product)
				{
					$object = new Varien_Object();
					$object->setData('product', $_product);
					if($catalogRule->validate($object))			
						$tam[]	=	$_product->getId();
				}
			}
			if(!$tam) $tam = 'empty';
			//echo '<pre>';print_r($tam);exit;
			$lib_multicache	=	Mage::helper('productsfilterwidget/multicache');
			$lib_multicache->set('conditions_'.$in['time'],$tam,$in['cache_time']*60);
		}	
		
		//echo '<pre>';print_r($tam);exit;
		if($tam	==	'empty')	$tam = '';
		if($in['sort_by'] == 'position')	$in['sort_by'] = 'entity_id';
			
			$result = Mage::getModel('productsfilterwidget/product')->getCollection()->addAttributeToFilter('entity_id',array(
													'in' => $tam
													));
			
			if($in['sort_by'] == 'random')										
				$result->getSelect()->order(new Zend_Db_Expr('RAND()'));
			elseif($in['sort_by'] == 'mostviews')
			{							
				$mostviews = Mage::getResourceModel('reports/product_collection')
				->addViewsCount()
				->addAttributeToFilter('entity_id',array(
													'in' => $tam
													));			
				$result	=	$mostviews;						
			}
			else
				$result->setOrder($in['sort_by'],$in['sort_direction']);
					
			//Mage::register('count',$result->count());
			$result->addAttributeToSelect('*')->addAttributeToFilter('visibility', $visibility)->setPageSize($in['limit_count'])->setcurPage($this->getRequest()->getParam('p',1));		
			
			//echo '<pre>';print_r($result->getData());exit;
			//echo (string)$result->getSelect();exit;
			$this->setCollection($result);	
			$this->_defaultToolbarBlock = 'productsfilterwidget/toolbar';
		
			return $this->_productCollection;
		
		
    }
	

    
    public function getProductsFilterWidget()     
    { 
        if (!$this->hasData('productsfilterwidget')) {
            $this->setData('productsfilterwidget', Mage::registry('productsfilterwidget'));
        }
        return $this->getData('productsfilterwidget');
        
    }
	
	public function getConfigs()
	{		
		$input['cache_time']		=	$this->getData('cache_time');
		$input['col_count']			=	$this->getData('col_count');
		$input['limit_count']		=	$this->getData('limit_count');
		$input['sort_by']			=	$this->getData('sort_by');
		$input['sort_direction']	=	$this->getData('sort_direction');		
		$input['toolbar']			=	$this->getData('toolbar');
		$plit	=	explode('-',$this->getData('conditions'));
		$input['conditions']		=	Mage::helper('core')->urlDecode($plit[0]);	
		$input['time']				=	$plit[1];
		//echo '<pre>';print_r($input);exit;
		return $input;
	}
	
	protected function _toHtml()
    {   
		if($this->getData('template')	==	'custom_template')
		{	$this->setTemplate($this->getData('custom_theme'));		}
        return parent::_toHtml();
    }
	
	public function getColumnCount()
	{
		return $this->getData('col_count');
	}

	
}