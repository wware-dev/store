<?php

class GrafischDirect_Filterproducten_Model_Mysql4_Productsfilterwidget_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('productsfilterwidget/productsfilterwidget');
    }
}