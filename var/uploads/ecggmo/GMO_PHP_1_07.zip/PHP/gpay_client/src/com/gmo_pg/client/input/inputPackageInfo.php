<?php
/**
 * パッケージ input
 * 
 * <p>
 *  このパッケージは、実行クラス(xxTran)に渡すパラメータの保持クラスが含まれます。
 * 加盟店様は、このパッケージのクラスをインスタンス化し、setterで呼び出しパラメータを設定します。
 * </p>
 * @package com.gmo_pg.client
 * @subpackage input
 */
?>