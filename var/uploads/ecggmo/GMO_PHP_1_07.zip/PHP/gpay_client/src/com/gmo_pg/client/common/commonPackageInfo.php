<?php
/**
 * パッケージ common
 * 
 * <p>
 *  このパッケージは、モジュールタイプが共通して利用するクラス・定数を含みます。、
 * 加盟店様がこのパッケージに属するクラスを直接利用することは、通常ありません。
 * </p>
 * @package com.gmo_pg.client
 * @subpackage common
 * 
 */
?>